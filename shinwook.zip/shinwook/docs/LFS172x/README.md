# Labs for Linux Foundation Course LFS172x

The following labs in this GitHub repository are included in the course:

- [Aries Messages Lab](aries-messages-lab.md)
- [Browsing an Indy Ledger](BrowsingAnIndyLedger.md)
- [Public and Private DIDs](PublicAndPrivateDIDs.md)
- [Running Aries Agents in a Browser](running-aries-browser-lab.md)
- [Tools for building Social Recovery Mechanisms](SocialRecoveryLab.md)

As things change in these materials, updates will be made to this [Change Log](ChangeLog.md).