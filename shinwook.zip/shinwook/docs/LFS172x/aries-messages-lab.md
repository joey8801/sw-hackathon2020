# Screencast: Aries Connections and Messaging

In this presentation, we'll use a couple of Aries agents to establish a connection between the agents and to exchange messages using a couple of DIDComm protocols.

To start the presentation, click [here](https://youtu.be/He1QHYuYxlw).

Want to run the example yourself?  Click [here](agentbook-acapy.md) for instructions on running through the process yourself.
